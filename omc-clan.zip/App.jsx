import React from "react";
import MemberForm from "./MemberForm";
import MemberList from "./MemberList";

export default function App() {
  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      <h1 className="text-4xl font-bold text-center mb-8">OMC Minecraft Clan</h1>
      <MemberForm />
      <MemberList />
    </div>
  );
}
