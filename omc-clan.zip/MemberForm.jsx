import React, { useState } from "react";
import { db } from "./firebase";
import { collection, addDoc } from "firebase/firestore";

export default function MemberForm() {
  const [name, setName] = useState("");
  const [role, setRole] = useState("Mitglied");
  const [description, setDescription] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    await addDoc(collection(db, "members"), {
      name,
      role,
      description,
      timestamp: Date.now()
    });
    setName("");
    setRole("Mitglied");
    setDescription("");
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="max-w-md mx-auto bg-gray-800 p-6 rounded-2xl shadow-lg mb-8"
    >
      <h2 className="text-2xl font-semibold mb-4">Mitglied eintragen</h2>
      <input
        className="w-full p-2 mb-2 rounded bg-gray-700"
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <select
        className="w-full p-2 mb-2 rounded bg-gray-700"
        value={role}
        onChange={(e) => setRole(e.target.value)}
      >
        {["Mitglied", "Farmer", "Builder", "SrBuilder", "Alrounder", "lagerleitung", 
          "VIP", "Builderleitung", "SUP", "SrSUP", "Mod", "SrMod", "Admin", "Leader"].map(r => (
          <option key={r} value={r}>{r}</option>
        ))}
      </select>
      <textarea
        className="w-full p-2 mb-2 rounded bg-gray-700"
        placeholder="Beschreibung"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      />
      <button
        type="submit"
        className="bg-green-600 px-4 py-2 rounded hover:bg-green-700"
      >
        Abschicken
      </button>
    </form>
  );
}
