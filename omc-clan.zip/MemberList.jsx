import React, { useEffect, useState } from "react";
import { db } from "./firebase";
import { collection, onSnapshot, query, orderBy } from "firebase/firestore";

export default function MemberList() {
  const [members, setMembers] = useState([]);

  useEffect(() => {
    const q = query(collection(db, "members"), orderBy("timestamp", "desc"));
    const unsub = onSnapshot(q, (snapshot) => {
      setMembers(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsub();
  }, []);

  return (
    <div className="max-w-3xl mx-auto">
      <h2 className="text-2xl font-semibold mb-4">Mitgliederliste</h2>
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3">
        {members.map((m) => (
          <div
            key={m.id}
            className="bg-gray-800 p-4 rounded-xl shadow-md border-l-4 border-green-500"
          >
            <h3 className="text-xl font-bold">{m.name}</h3>
            <p className="text-sm text-green-400">{m.role}</p>
            <p className="mt-2 text-sm">{m.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
